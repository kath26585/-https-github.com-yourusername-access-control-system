from flask import Flask, render_template_string, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os

# Initialize the Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'  # Change this to a more secure key in production
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///access_control.db'
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}
db = SQLAlchemy(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Database models
class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('role.id'), nullable=False)
    profile_pic = db.Column(db.String(200), nullable=True)
    
    role = db.relationship('Role', backref=db.backref('users', lazy=True))

# Initialize database
@app.before_request
def init_db():
    db.create_all()

    if not Role.query.filter_by(name='Admin').first():
        admin_role = Role(name='Admin')
        db.session.add(admin_role)
        db.session.commit()

    if not Role.query.filter_by(name='User').first():
        user_role = Role(name='User')
        db.session.add(user_role)
        db.session.commit()

    if not User.query.filter_by(username='admin').first():
        admin_user = User(username='admin', password_hash=generate_password_hash('admin1234'), role_id=1)
        db.session.add(admin_user)
        db.session.commit()

    if not User.query.filter_by(username='user').first():
        user_user = User(username='user', password_hash=generate_password_hash('user1234'), role_id=2)
        db.session.add(user_user)
        db.session.commit()

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Route for login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))

        flash('Invalid credentials. Please try again.', 'danger')

    return render_template_string('''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Login</title>
        </head>
        <body>
            <h1>Login</h1>
            <form method="POST">
                <label for="username">Username</label>
                <input type="text" name="username" required>

                <label for="password">Password</label>
                <input type="password" name="password" required>

                <button type="submit">Login</button>
            </form>
            {% with messages = get_flashed_messages(with_categories=true) %}
                {% if messages %}
                    <ul>
                    {% for category, message in messages %}
                        <li>{{ message }}</li>
                    {% endfor %}
                    </ul>
                {% endif %}
            {% endwith %}
        </body>
        </html>
    ''')

# Route for registration (Admin only)
@app.route('/register', methods=['GET', 'POST'])
@login_required
def register():
    if current_user.role.name != 'Admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role_name = request.form['role']
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists!', 'danger')
            return redirect(url_for('register'))

        role = Role.query.filter_by(name=role_name).first()
        if not role:
            flash('Invalid role selected!', 'danger')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)
        new_user = User(username=username, password_hash=hashed_password, role_id=role.id)
        db.session.add(new_user)
        db.session.commit()
        flash('User registered successfully!', 'success')
        return redirect(url_for('dashboard'))

    return render_template_string('''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Register</title>
        </head>
        <body>
            <h1>Register User</h1>
            <form method="POST">
                <label for="username">Username</label>
                <input type="text" name="username" required>

                <label for="password">Password</label>
                <input type="password" name="password" required>

                <label for="role">Role</label>
                <select name="role">
                    <option value="Admin">Admin</option>
                    <option value="User">User</option>
                </select>

                <button type="submit">Register</button>
            </form>
            {% with messages = get_flashed_messages(with_categories=true) %}
                {% if messages %}
                    <ul>
                    {% for category, message in messages %}
                        <li>{{ message }}</li>
                    {% endfor %}
                    </ul>
                {% endif %}
            {% endwith %}
        </body>
        </html>
    ''')

# Route for dashboard (protected)
@app.route('/dashboard')
@login_required
def dashboard():
    return render_template_string('''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Dashboard</title>
        </head>
        <body>
            <h1>Welcome, {{ name }}!</h1>
            <p>Role: {{ current_user.role.name }}</p>
            <a href="{{ url_for('logout') }}">Logout</a> | 
            <a href="{{ url_for('profile') }}">Profile</a> | 
            <a href="{{ url_for('register') }}">Register New User</a>
        </body>
        </html>
    ''', name=current_user.username)

# Route to logout
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# Route for profile page (protected)
import os

# Route for profile page (protected)
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    # Ensure the upload folder exists
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])

    if request.method == 'POST':
        new_username = request.form['username']
        new_password = request.form['password']
        
        if new_username:
            current_user.username = new_username

        if new_password:
            current_user.password_hash = generate_password_hash(new_password)

        if 'profile_pic' in request.files:
            file = request.files['profile_pic']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                current_user.profile_pic = filename

        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile'))
    
    return render_template_string('''
    <html>
        <body>
            <h2>Profile</h2>
            <form method="POST" enctype="multipart/form-data">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="{{ username }}" required><br><br>
                
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required><br><br>
                
                <label for="profile_pic">Profile Picture:</label>
                <input type="file" id="profile_pic" name="profile_pic"><br><br>

                <input type="submit" value="Update Profile">
            </form>
            {% if profile_pic %}
                <h3>Your Profile Picture:</h3>
                <img src="{{ url_for('static', filename='uploads/' + profile_pic) }}" width="100" height="100"><br><br>
            {% endif %}
        </body>
    </html>
    ''', username=current_user.username, profile_pic=current_user.profile_pic)
# Helper function to check file extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Main entry point to run the app
if __name__ == "__main__":
    app.run(debug=True)